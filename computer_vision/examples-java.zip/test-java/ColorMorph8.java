public class ColorMorph8 extends ColorMorph {

	int pixelOperation(int i, int j) {
		int rmax = 0, gmax = 0, bmax = 0;

		for(int ii=i-1; ii<=i+1; ii++) {
			for(int jj=j-1; jj<=j+1; jj++) {
				int val = in[ii][jj];
				int v = (val >> 16) & 255;
				if(v>rmax) rmax = v;
				v = (val >> 8) & 255;
				if(v>gmax) gmax = v;
				v = val & 255;
				if(v>bmax) bmax = v;
			}
		}
		return (rmax<<16) | (gmax<<8) | bmax;
	}

	public static void main(String[] args) {
		new ColorMorph8().init(args).saveMatrix(args[1]);
	}
}

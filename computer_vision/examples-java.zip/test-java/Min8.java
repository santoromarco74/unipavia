import java.io.IOException;

public class Min8 extends Morph {

	public Min8(double[][] in, double[][] out, int i) {
		super(in, out, i);
	}

	public double pixelOperation(int i, int j) {
		double min = in[i][j];
		double val = in[i-1][j];
		if(min>val) min = val;
		val = in[i][j-1];
		if(min>val) min = val;
		val = in[i][j+1];
		if(min>val) min = val;
		val = in[i+1][j];
		if(min>val) min = val;
		val = in[i-1][j-1];
		if(min>val) min = val;
		val = in[i-1][j+1];
		if(min>val) min = val;
		val = in[i+1][j-1];
		if(min>val) min = val;
		val = in[i+1][j+1];
		if(min>val) min = val;
		return min;
	}

	public static void main(String[] args) throws IOException {
		int iter = args.length>2? Integer.parseInt(args[2]) : 1;
		double[][] in = Utils.loadMatrix(args[0]);
		Morph op = new Min8(in, null, iter);
		Utils.saveMatrix(args[1], op.getMatrix());
	}
}

import java.io.IOException;

public class Max extends Morph {

	public Max(double[][] in, double[][] out, int i) {
		super(in, out, i);
	}

	public double pixelOperation(int i, int j) {
		double max = in[i][j];
		double val = in[i-1][j];
		if(max<val) max = val;
		val = in[i][j-1];
		if(max<val) max = val;
		val = in[i][j+1];
		if(max<val) max = val;
		val = in[i+1][j];
		if(max<val) max = val;
		return max;
	}

	public static void main(String[] args) throws IOException {
		int iter = args.length>2? Integer.parseInt(args[2]) : 1;
		double[][] in = Utils.loadMatrix(args[0]);
		Morph op = new Max(in, null, iter);
		Utils.saveMatrix(args[1], op.getMatrix());
	}
}

import java.io.IOException;

public class Open {

	public static void main(String[] args) throws IOException {
		int iter = args.length>2? Integer.parseInt(args[2]) : 5;
		double[][] in = Utils.loadMatrix(args[0]);
		Morph op = new Min(in, null, iter);
		op = new Max(op.getMatrix(), null, iter);
		Utils.saveMatrix(args[1], op.getMatrix());
	}
}

import java.io.IOException;

public class Close {

	public static void main(String[] args) throws IOException {
		int iter = args.length>2? Integer.parseInt(args[2]) : 5;
		double[][] in = Utils.loadMatrix(args[0]);
		Morph op = new Max(in, null, iter);
		op = new Min(op.getMatrix(), null, iter);
		Utils.saveMatrix(args[1], op.getMatrix());
	}
}

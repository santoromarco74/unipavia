package cv.imageframe;

import java.util.Timer;
import java.util.TimerTask;

public class ImageFrameGallery extends TimerTask {

	static ImageFrame f;
	static String[] images;
	static int index=0;
	
	public static void main(String[] args) {
		f = new ImageFrame(args[0]);
		images = args;
		int period=Integer.getInteger("period", 5000);
		new Timer().schedule(new ImageFrameGallery(), period, period);
	}

	public void run() {
		f.setImage(images[++index % images.length]);
		f.pack(); // ???
	}

}

clear;
% model a LTI having the following equation
% x1/dt = 3x1 + 2x2 +u
% x2/dt = x2
% y = 3x1 + 0.5u

%[x1/dt ; x2/dt] = A x + B u
% y = Cx + D u
A = [-3 2 ; 0 -1];
B = [1 0]';
C = [3 0];
D = 0;
xo = 0;
sys = ss(A,B,C,D);
step(sys);



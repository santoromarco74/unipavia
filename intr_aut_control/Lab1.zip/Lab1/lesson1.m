
%  data example
A = 3; % number
B = 'hello'; % string
D = true;   % boolean

%MATix LABoratory
A = [1 2 3 ; 4 5 6];
%identity
I = eye(4);
C = zeros(3,4);
U = ones(4,6);
%main matrix operation
A+3;
A+A
% product row column rules
A*eye(3)
% element produc (same dimension matrix)
[ 1 2 3; 1 2 3].*[ -1 -1 -1; 1 1 1]  
% transposition 
A'


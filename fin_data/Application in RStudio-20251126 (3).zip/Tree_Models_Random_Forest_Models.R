###################################
############ TREE MODELS ##########
###################################
# Clear the environment
rm(list=ls())

# Install the following packages if not installed yet                         
# install.packages("readxl")
install.packages("rpart")
install.packages("partykit")
install.packages("rattle")
install.packages("rpart.plot")
# install.packages("caret")
# install.packages("ggplot2")
# install.packages("ROCR")
install.packages("randomForest")

# Call libraries
library(readxl) 
library(rpart) 
library(partykit) 
library(rattle) 
library(rpart.plot) 
library(caret) 
library(ggplot2)
library(ROCR) 
library(randomForest) 

# Import Bank Marketing dataset (public)
## [Moro et al., 2014] S. Moro, P. Cortez and P. Rita
## "A Data-Driven Approach to Predict the Success of Bank Telemarketing" (Decision Support Systems)
## Input variables:
        # bank client data:
# age (numeric)
# job : type of job (categorical: "admin.","blue-collar","entrepreneur","housemaid","management","retired","self-employed","services","student","technician","unemployed","unknown")
# marital : marital status (categorical: "divorced","married","single","unknown")
# education (categorical: "basic.4y","basic.6y","basic.9y","high.school","illiterate","professional.course","university.degree","unknown")
# housing: has housing loan? (categorical: "no","yes","unknown")
# loan: has personal loan? (categorical: "no","yes","unknown")
        # related with the last contact of the current campaign:
# contact: contact communication type (categorical: "cellular","telephone") 
# month: last contact month of year (categorical: "jan", "feb", "mar", ..., "nov", "dec")
# day_of_week: last contact day of the week (categorical: "mon","tue","wed","thu","fri")
# duration: last contact duration, in seconds (numeric)
        # other attributes:
# campaign: number of contacts performed during this campaign and for this client (numeric, includes last contact)
# pdays: number of days that passed by after the client was last contacted from a previous campaign (numeric; missing if the client was not contacted in previous campaigns)
# previous: number of contacts performed before this campaign and for this client (numeric)
# poutcome: outcome of the previous marketing campaign (categorical: "failure","nonexistent","success")

## Output variable (desired target):
# y - has the client subscribed a term deposit? (binary: "yes","no")
bank_marketing<-read_excel('path/bank_marketing.xlsx')
data<-as.data.frame(bank_marketing)

data$y<-as.factor(data$y)

for (i in 1:9){
data[i]<-lapply(data[i],as.factor)
}

attach(data)

# Count the cases in which the target variable is equal to "yes" (success percentage)
yes_perc<-nrow(data[data$y=='yes',])/nrow(data)*100
print(yes_perc)

# Stratified Sampling --> considering the target variable as a strata
set.seed(1000)
div<-createDataPartition(y=data$y,p=0.7,list=F)

# Training Sample
data.train<-data[div,] # 70% here

# Test Sample
data.test<-data[-div,] # rest of the data (30%) goes here

# We use the CART decision tree algorithm
# The CART algorithm for classification trees minimizes the Gini impurity in each group
fit1<-rpart(y~.,data=data.train,method="class")

# Print tree detail
printcp(fit1)

# Plot the tree
plot(fit1,margin=0.2,main="Tree: Recursive Partitioning")
text(fit1,cex=0.8) 

prp(fit1,type=2,extra=1,main="Tree: Recursive Partitioning") # type=2 draws the split labels below the node labels
                                                             # extra=1 displays the number of observations that fall in the node 
fancyRpartPlot(fit1)

# Make predictions on the test sample
data.test$fit1_score<-predict(fit1,type='prob',data.test)
fit1_pred<-prediction(data.test$fit1_score[,2],data.test$y)
fit1_perf<-performance(fit1_pred,"tpr","fpr")

# Model performance plot
plot(fit1_perf,lwd=2,colorize=TRUE,main="ROC Fit1: Recursive Partitioning")
lines(x=c(0,1),y=c(0,1),col="red",lwd=1,lty=3)

# AUROC, KS and GINI
# The KS statistic is the maximum difference between the cumulative percentage of "yes" (cumulative true positive rate)
# and the cumulative percentage of "no" (cumulative false positive rate)
# The Gini coefficient is measured in values between 0 and 1, where a score of 1 means that the model is 100% accurate
# in predicting the outcome, While a Gini score equal to 0 means that the model is entirely inaccurate (random model).
fit1_AUROC<-round(performance(fit1_pred,measure="auc")@y.values[[1]]*100,2)
fit1_KS<-round(max(attr(fit1_perf,'y.values')[[1]]-attr(fit1_perf,'x.values')[[1]])*100,2)
fit1_Gini<-(2*fit1_AUROC-100)
CART_tree<-cat("AUROC:",fit1_AUROC,"KS:",fit1_KS,"Gini:",fit1_Gini)

# Conditional inference tree --> 
# Both rpart and ctree recursively perform univariate splits 
# of the target variable based on values on the other variables in the dataset
# Differently from the CART, ctree uses a significance test procedure 
# in order to select variables instead of selecting the variables that minimize the Gini impurity.
fit2<-ctree(y~.,data=data.train)

# Summary
fit2

# This is essentially a decision tree but with extra information in the terminal nodes.
plot(fit2,gp=gpar(fontsize=6),ip_args=list(abbreviate=FALSE,id=FALSE))

# Make predictions on the test sample
data.test$fit2_score<-predict(fit2,type='prob',data.test)
fit2_pred<-prediction(data.test$fit2_score[,2],data.test$y)
fit2_perf<-performance(fit2_pred,"tpr","fpr")

# Model performance plot
plot(fit2_perf,lwd=2,colorize=TRUE,main="ROC Fit2: Conditional Inference Tree")
lines(x=c(0,1),y=c(0,1),col="red",lwd=1,lty=3)

#  AUROC, KS and GINI
fit2_AUROC<-round(performance(fit2_pred, measure = "auc")@y.values[[1]]*100,2)
fit2_KS<-round(max(attr(fit2_perf,'y.values')[[1]]-attr(fit2_perf,'x.values')[[1]])*100,2)
fit2_Gini<-(2*fit2_AUROC-100)
cond_inf_tree<-cat("AUROC:",fit2_AUROC,"KS:",fit2_KS,"Gini:",fit2_Gini)

############################################
############ RANDOM FOREST MODELS ##########
############################################
set.seed(150)
fit3<-randomForest(y~.,data=data.train,na.action=na.roughfix)

fit3_fitForest<-predict(fit3,newdata=data.test,type="prob")[,2]
fit3_fitForest.na<-as.data.frame(cbind(data.test$y,fit3_fitForest))
colnames(fit3_fitForest.na)<-c('y','pred')
fit3_fitForest.narm<-as.data.frame(na.omit(fit3_fitForest.na)) # remove NA (missing values)

fit3_pred<-prediction(fit3_fitForest.narm$pred,fit3_fitForest.narm$y)
fit3_perf<-performance(fit3_pred,"tpr","fpr")

#Plot variable importance
varImpPlot(fit3,main="Random Forest: Variable Importance")

# Model Performance plot
plot(fit3_perf,colorize=TRUE,lwd=2,main="fit3 ROC: Random Forest",col="blue")
lines(x=c(0,1),y=c(0,1),col="red",lwd=1,lty=3)

# AUROC, KS and GINI
fit3_AUROC<-round(performance(fit3_pred, measure="auc")@y.values[[1]]*100,2)
fit3_KS<-round(max(attr(fit3_perf,'y.values')[[1]]-attr(fit3_perf,'x.values')[[1]])*100,2)
fit3_Gini<-(2*fit3_AUROC-100)
rand_for<-cat("AUROC:",fit3_AUROC,"KS:",fit3_KS,"Gini:",fit3_Gini)

#Compare ROC Performance of the 3 models
plot(fit1_perf,col='blue',lty=1,main='ROCs: Model Performance Comparison') # Recursive partitioning
plot(fit2_perf,col='gray',lty=2,add=TRUE); # Conditional inference tree
plot(fit3_perf, col='red',lty=3,add=TRUE); # Random forest
lines(c(0,1),c(0,1),col= "green",lty=4) # random line

legend(0.6,0.5, c('Fit1: Recursive partitioning (AUROC=79.85)','Fit2: Conditional inference tree (AUROC=91.86)','Fit3: Random forest (AUROC=79.3)', 'Random line'),
col=c('blue','grey','red','green'),lwd=c(1,2,3), cex=0.7)



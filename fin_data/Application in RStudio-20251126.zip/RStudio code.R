####################################################################################################
##################################### LINEAR REGRESSION MODELS #####################################
####################################################################################################
# Clear the environment 
rm(list=ls())

# Install packages by removing the # and running the lines 
install.packages("ggplot2",dependencies=TRUE)
install.packages("readxl",dependencies=TRUE)
install.packages("corrplot",dependencies=TRUE)

# Call libraries
library(ggplot2)
library(readxl)
library(corrplot)

# Import dataset including 713 observations corresponding to the days where the prices of the Bitcoins in 8 
# different exchange markets were recorded together with the prices of the classical assets and the exchane
# rates
exchanges<-read_excel("path/exchanges.xlsx")

data<-exchanges

# Remove the first column from data
data1<-data[-1]

# Create a separate dataset with returns instead of prices (log(x)-log(x-1))
data2<-as.data.frame(sapply(data1,function(x)diff(log(x),lag=1)))

# Bring the names of the variables directly into memory
attach(data2)

# Run a simple linear regression y=a+bx [btc_coinbase on sp500]
model<-lm(btc_coinbase~sp500,data=data2)
summary(model)

# Run a simple linear regression [btc_coinbase on btc_kraken]
model_2<-lm(btc_coinbase~btc_kraken,data=data2)
summary(model_2)

# Run a multiple linear regression [btc_coinbase on all other variables]
model_3<-lm(btc_coinbase~.,data=data2)
summary(model_3)

coeff<-model_3$coefficients

# Get and plot residuals
res<-model_3$residuals
#res<-residuals(model_3)

# Plot of the residuals
plot(res,type='l')

# Convert to DataFrame for ggplot
res<-as.data.frame(res)

# Check residuals' distribution 
ggplot(res,aes(res))+geom_histogram(fill='blue',alpha=0.5,binwidth=0.003)

# Some plots for model diagnostics
# hitting return key you move from a plot to another
plot(model_3)

# Get fitted values 
fit<-model_3$fitted.values
#fit<-fitted.values(model_3)

date_returns<-data$Date[2:nrow(data)]

results<-cbind.data.frame(date_returns,data2$btc_coinbase,fit)
colnames(results)<-c('Date','Observed','Fitted')

# Plot observed vs fitted values
ggplot(results,aes(Date))+ 
  geom_line(aes(y=Observed,colour="Observed"))+ 
  geom_line(aes(y=Fitted,colour="Fitted"))+
  ylab('Returns')+
  ggtitle('Btc coinbase: in-sample fit')+theme(plot.title=element_text(hjust=0.5))

# Evaluate model prediction 
# One of the most used measures is MSE (mean squared error)
mse<-mean((results$Fitted-results$Observed)^2)
print(mse)

# Root mean squared error
mse^0.5

# R-Squared determination coefficient value for our model 
SSE<-sum((results$Fitted-results$Observed)^2)
SST<-sum((results$Observed-mean(results$Observed))^2)
R2<-1-SSE/SST
R2

# Split the sample in two, to make out-of-sample predictions 
data2_in<-data2[1:500,]
data2_out<-data2[501:nrow(data2),]

# Estimate the model on the first subsample
model_out<-lm(btc_coinbase ~.,data=data2_in)

# Apply the model to the second subsample
fit_out<-predict(model_out,data2_out)

date_returns_out<-date_returns[501:nrow(data2)]

results_out<-cbind.data.frame(date_returns_out,data2_out$btc_coinbase,fit_out)
colnames(results_out)<-c('Date','Observed','Fitted')

# Calculate RMSE for the out-of-sample predictions
rmse<-sqrt(mean((results_out$Fitted-results_out$Observed)^2))
print(rmse)







###########################################################################################
############################# LOGISTIC REGRESSION MODELS ##################################
###########################################################################################
# Clear the environment
rm(list=ls())

# Packages that need to be installed if not yet
#install.packages("readxl")
install.packages("caret",dependiecies=TRUE)
install.packages("data.table",dependencies=TRUE)

# Calling the libraries
library(readxl)
library(caret)
library(data.table)

# Import dataset 
# 6018 companies for which we observe: balance sheet data in 2014, status (active/defaulted) in 2015
# "Default" is a binary variable assuming values 0 (no default) or 1 (default)

Companies_data<-read_excel("path/Companies data.xlsx")
data<-as.data.frame(Companies_data)

attach(data)

## Get default rate
def_perc<-sum(data$Default)/length(data$Default)
print(def_perc)

# LOGISTIC REGRESSION 
# Transform "Default" and "Loss" variables to factors
data$Default<-as.factor(data$Default)
data$Loss_dummy<-as.factor(data$Loss_dummy)

# An example of comparing the distribution of a variable between the two groups
# Plot the distribution of ROE accross different status (Default=0; Default=1)
ggplot(data,aes(ROE,fill=Default))+geom_density(alpha=0.2)

# Split the dataset into training and testing samples 
# Sampling: a) Random Sampling and b) Stratified Sampling 

# a) Random Sampling 
# Set a random seed so that your results can be reproduced
set.seed(300)

perc<-0.7
n_train<-round(perc*nrow(data))
data_sample<-data[sample(nrow(data)),]          
data.train<-data_sample[1:n_train,]              
data.test<-data_sample[(n_train+1):nrow(data_sample),]    

# Let's define our own function "percentage", to make some exercise with user-defined functions
percentage<-function(x){
y<-as.numeric(levels(x))[x]
prc<-sum(y)/length(y)*100
prc
}

percentage(data$Default)
percentage(data.train$Default)
percentage(data.test$Default) ## the percentage of defaults in the test sample is quite different 
                              ## from the percentage in the training sample

# With a simple random sampling technique, we are not sure whether 
# the subgroups of the Default variable are represented equally or proportionately within the two sub-samples.

# b) Stratified Sampling 
set.seed(300)
                            
div<-createDataPartition(y=data$Default,p=perc,list=F)
   
# Training Sample
data.train_1<-data[div,] # 70% here
percentage(data.train_1$Default)

# Test Sample
data.test_1<-data[-div,] # the rest of the data goes here
percentage(data.test_1$Default) # now the percentage of defaults in the two sub-samples is quite similar 

### MODEL WITH ALL VARIABLES (for the time being)
fit1<-glm(Default~.,data=data.train_1,family=binomial())
summary(fit1)

## Odds ratios 
exp(coefficients(fit1)) # how do you interpret the exp of coefficients?

## Get predicted default probabilities
data.test_1$score<-predict(fit1,type='response',data.test_1)

# Decide a cut-off and get predictions
cut_off<-def_perc
data.test_1$pred<-ifelse(data.test_1$score<=cut_off,0,1)

# Does the model classify the companies well?
# Let's introduce some measures used to investigate the performance of models for binary variables:  
# false positive rate and false negative rate, sensitivity and specificity
# you will see them in more detail during next lesson

##false negative rate
n_neg<-nrow(data.test_1[data.test_1$Default=='0',])
data.test_1$fp_flag<-ifelse(data.test_1$pred==1 & data.test_1$Default=='0',1,0)
fpr<-sum(data.test_1$fp_flag)/n_neg #false positive rate

##false positive rate
n_pos<-nrow(data.test_1[data.test_1$Default=='1',])
data.test_1$fn_flag<-ifelse(data.test_1$pred==0 & data.test_1$Default=='1',1,0)
fnr<-sum(data.test_1$fn_flag)/n_pos #false positive rate

##sensitivity
1-fnr

##specificity
1-fpr


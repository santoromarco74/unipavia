###########################
##### NEURAL NETWORKS #####
###########################
# Clear the environment 
rm(list=ls())

# Install packages by removing the # and running the lines 
#install.packages("readxl")
install.packages("readr")
#install.packages("ggplot2")                                  
install.packages("nnet")
install.packages("neuralnet")

# Call libraries 
library(readxl)
library(readr)
library(ggplot2)
library(nnet)
library(neuralnet)

#####################################
########## APPLICATION ETF ##########
#####################################
# Import data on the return of 52 Italian ETF (Exchange Traded Funds) 
# classified by their riskiness (6 classes), over a period of 31 days
ETF_Italian_31days<-read_csv("path/ETF_Italian_31days.csv")

# Rename the dataset and transform into a dataframe                                
data<-as.data.frame(ETF_Italian_31days)

# Descriptive statistics 
summary(data)

# Target variable --> class 
table(data$class)

# In this case, the dependent variable is the "class" and we need to encode it.
# This means that, from 1 variable "class", we will get 6 that will take the values 1/0.
train<-cbind(data[,2:32],class.ind(as.factor(data$class)))

# Set labels for the new created columns while keeping the same names for other columns
names(train)<-c(names(data)[2:32],"c1","c2","c3","c4","c5","c6")

# Let's fit a neural network on the full dataset
set.seed(134)
nn5<-neuralnet(c1+c2+c3+c4+c5+c6~.,data=train,
hidden=c(5),  # 5 neurons in the hidden layer
act.fct="logistic",
err.fct='ce', ## entropy-based error measure
linear.output=FALSE,
lifesign="minimal")

# Plot the neural network with 5 hidden units
plot(nn5)

# Let's change the number of neurons in the hidden layer (= 15)
set.seed(134)
nn<-neuralnet(c1+c2+c3+c4+c5+c6~.,data=train,
hidden=c(15),
act.fct="logistic",
err.fct='ce',
linear.output=FALSE,
lifesign="minimal")

# Plot the neural network with 15 hidden units
plot(nn)

##### Let's have a look at the accuracy on the training set (in-sample accuracy) #####
# Compute predictions
nn_pred<-compute(nn,train[,1:31])
# Extract results
nn_pred1<-nn_pred$net.result
head(nn_pred1)

# Accuracy (in-sample)
original_values<-max.col(train[,32:37])
predicted<-max.col(nn_pred1)
mean<-mean(predicted==original_values)

# Initialise vector of results 
outs<-NULL

# Train-test split proportions
proportion<-0.80

# 5-fold cross validation
k=5

# Crossvalidate
# Set seed for reproducibility purposes
set.seed(134)

for(i in 1:k){index<-sample(1:nrow(train),round(proportion*nrow(train)))
train_cv<-train[index,]
test_cv<-train[-index,]
nn_cv<-neuralnet(c1+c2+c3+c4+c5+c6~.,data=train_cv,
hidden=c(20),
act.fct="logistic",
err.fct="ce",
linear.output=FALSE)
  
# Compute predictions
nn_pred<-compute(nn_cv,test_cv[,1:31])
# Extract results
nn_pred1<-nn_pred$net.result

# Evaluate Accuracy
original_values<-max.col(test_cv[,32:37])
predicted<-max.col(nn_pred1)
outs[i]<-mean(predicted==original_values)
}

mean(outs)

##########################################
########## APPLICATION BITCOINS ##########
##########################################
rm(list=ls())

# Import the bitcoin prices dataset
exchanges<-read_excel("path/exchanges.xlsx")

# Make a copy which we use for the analysis and calculate returns                                
data<-as.data.frame(sapply(exchanges[,-1],function(x)diff(log(x),lag=1)))
data<-as.data.frame(cbind(exchanges[2:nrow(exchanges),1],data))

# We choose the return of Bitcoin on Coinbase as response variable
# We train the neural network on the 2016-2017 period and predict returns in 2018
train<-data[data$Date<='2017-12-31',2:ncol(data)]

# Let's fit a neural network on the training dataset. 
set.seed(123)
nn<-neuralnet(btc_coinbase~.,data=train,hidden=c(5),linear.output=TRUE,lifesign="minimal")

# Plot the neural network 
plot(nn)

# Select the test dataset
test<-data[data$Date>'2017-12-31',2:ncol(data)]

set.seed(123)
nn_pred<-compute(nn,test)
# Extract results
predicted<-nn_pred$net.result
  
# Evaluate Accuracy
original_values<-test$btc_coinbase
rmse<-sqrt(mean((original_values-predicted)^2))



#########################################################################
################ MODEL SELECTION FOR LOGISTIC MODELS ####################
#########################################################################
rm(list=ls())

# Packages that need to be installed if not yet
#install.packages("readxl")
#install.packages("caret")
install.packages("ROCR",dependiecies=TRUE)

# Calling the libraries
library(readxl)
library(caret)
library(ROCR)

# Import dataset 
# 6018 companies for which we observe: balance sheet data in 2014, status (active/defaulted) in 2015
# "Default" is a binary variable assuming values 0 (no default) or 1 (default)

SME_dataset<-read_excel("path/SME_dataset.xlsx")

data<-SME_dataset

# LOGISTIC REGRESSION

data$Default<-as.factor(data$Default)
data$Loss_dummy<-as.factor(data$Loss_dummy)

# Split the dataset into training and testing samples 
# Stratified Sampling 
perc<-0.7

set.seed(500)

# Create a partition of our data to lead cross-validation                      
div<-createDataPartition(y=data$Default,p=perc,list=F)
   
# Training Sample
data.train<-data[div,] # 70% here

# Test Sample
data.test<-data[-div,] # the rest of the data goes here

## Model including all predictors
fit1<-glm(Default~.,data=data.train,family=binomial())
summary(fit1)

## Stepwise regression
fit_step<-step(fit1,direction='both')
summary(fit_step)

##ANOVA
anova(fit_step,fit1,test="Chisq")

## Get predicted default probabilities
data.test$score<-predict(fit_step,type='response',data.test)
data.test$score1<-predict(fit1,type='response',data.test)

## Plot AUROC
perf_auroc<-performance(prediction(data.test$score,data.test$Default),"auc")
auroc<-as.numeric(perf_auroc@y.values)

perf_plot<-performance(prediction(data.test$score,data.test$Default),"tpr","fpr")
plot(perf_plot,main='ROC',col='blue',lwd=2)

## Compare AUROC
### note: in this case the two AUROCs are very close, so the two ROC curves are overlapping
perf_auroc1<-performance(prediction(data.test$score1,data.test$Default),"auc")
auroc1<-as.numeric(perf_auroc1@y.values)

perf_plot1<-performance(prediction(data.test$score1,data.test$Default),"tpr","fpr")

plot(perf_plot,main='ROC',col='blue',lwd=2)
plot(perf_plot1,add=TRUE,col='red',lwd=2) 
legend("right",legend=c("Model from stepwise","Full model"),lty=(1:1),col=c("blue","red"))



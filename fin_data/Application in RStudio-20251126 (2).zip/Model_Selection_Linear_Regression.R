#######################################################################
################ MODEL SELECTION FOR LINEAR MODELS ####################
#######################################################################
# Clear the environment 
rm(list=ls())

# Install packages by removing the # and running the lines 
install.packages("Hmisc",dependiecies=TRUE)
#install.packages("ggplot2")
#install.packages("readxl")
install.packages("corrplot",dependiecies=TRUE)
install.packages("ppcor",dependiecies=TRUE)

# Call libraries
library(readxl)
library(Hmisc)
library(ggplot2)
library(corrplot)
library(ppcor)

# Import dataset SME_dataset_2.xlsx 
SME_dataset_2<-read_excel("path/SME_dataset_2.xlsx")
data<-as.data.frame(SME_dataset_2)

# STRUCTURE AND DESCRIPTION OF THE DATASET 
# Dimension of our dataset
dim(data)

# Visualization of the first 6 rows
head(data)

# Descriptive statistics
summary(data)
str(data) 

data$NACE_group<-as.factor(data$NACE_group) # NACE_group is a number, but it cannot be used as a continuous variable

# LINEAR REGRESSION 
## Find the determinants of profitability (Return on Equity) of companies

# Check the distribution of ROE in the sample
boxplot(data$ROE)

# A way of dealing with (possible) outliers: winsorization
rmOutlier<-function(x){
low<-quantile(x,0.05,na.rm=T) 
high<-quantile(x,0.95,na.rm=T) 
out<-ifelse(x>high,high,ifelse(x<low,low,x)) 
out}

clean<-sapply(data[,-c(10:11)],rmOutlier)
data.clean<-cbind(clean,data[,10:11])

# Check all correlations by using the cor function 
correlations<-cor(data.clean[,-c(10:11)]) # we exclude non-numeric variables

# Visualize the correlation plot
corrplot(correlations,method="circle") 
corrplot(correlations,method="number") 

# Check partial correlations by using the pcor function 
p_correlations<-pcor(data.clean[,-c(10:11)])
pcor_mat<-p_correlations$estimate

# Visualize the partial correlation plot
corrplot(pcor_mat,method="circle") 
corrplot(pcor_mat,method="number") 

# Set a random seed so that your results can be reproduced
set.seed(1000)

# Split the dataset into training and testing samples 
n_train<-round(nrow(data.clean)*0.8) 
        
data.train<-data.clean[1:n_train,]              
data.test<-data.clean[(n_train+1):nrow(data.clean),]    

# Multiple linear regression on the training dataset
fit1<-lm(ROE~.-Default,data.train)
summary(fit1)

# Perform a stepwise linear regression 
# Forward
fit_step_f<-step(fit1,direction='forward')
summary(fit_step_f)

# Backward
fit_step_b<-step(fit1,direction='backward')
summary(fit_step_b)

# Backward and forward
fit_step<-step(fit1,direction='both')
summary(fit_step)

## ANOVA for model comparison
m0<-lm(ROE~1,data.train) #model with no predictors
m1<-fit_step       
anova(m0,m1)

m2<-fit1
anova(m1,m2)
  
## We found several significant relationships that explain companies' profitability: but is this a good predictive model? 
# Make predictions on the test dataset 
predictions<-predict(fit_step,data.test)
results<-cbind(data.test$ROE,predictions) 
colnames(results)<-c('Real','Predicted')
results<-as.data.frame(results)

# Calculate error measures
## MSE
mse<-mean((results$Real-results$Predicted)^2)
print(mse)

## RMSE
rmse<-sqrt(mse)
print(rmse)




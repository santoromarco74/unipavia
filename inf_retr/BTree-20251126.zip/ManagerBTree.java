package it.unipv.datastructures;

import it.unipv.datastructures.btree.BTree;

public class ManagerBTree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BTree bt = new BTree(2);
		
		bt.insert(90);
		bt.insert(50);
		bt.insert(30);
		bt.insert(70);
		bt.insert(80);
		bt.insert(10);
		
		bt.insert(20);
		bt.insert(60);
		bt.insert(40);
		bt.insert(95);
		bt.insert(55);
		bt.insert(35);
		
		bt.print();

	}

}

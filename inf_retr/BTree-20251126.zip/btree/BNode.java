package it.unipv.datastructures.btree;

public class BNode {
	
	private int minimumDegree = 0;
	private int keys[];
	private BNode children[];
	private boolean leaf = false;
	private int n = 0;
	
	public BNode(int minimumDegree)
	{
		this.minimumDegree = minimumDegree;
		this.keys = new int[2*minimumDegree - 1];
		this.children = new BNode[2*minimumDegree];
		
		for (int i = 0; i < 2*minimumDegree - 1; ++i)
			this.keys[i] = 0;
		for (int i = 0; i < 2*minimumDegree; ++i)
			this.children[i] = null;
	}
	
	public boolean isLeaf()
	{
		return this.leaf;
	}
	
	public boolean isFull()
	{
		if (n == 2*minimumDegree-1) return true;
		return false;
	}
	
	public void setLeaf()
	{
		this.leaf = true;
	}
	
	public void setChild(BNode c, int i)
	{
		this.children[i] = c;
	}
	
	public Object[] search(int k)
	{
		
		// Object[0] = BNode
		// Object[1] = id
		
		Object[] searchResult = new Object[2];
		
		int i = 0;
		
		while (i < this.n && this.keys[i] < k)
			++i;
		
		if (i < this.n && this.keys[i] == k)
		{
			searchResult[0] = this;
			searchResult[1] = i;
			return searchResult;
		}
		else if (this.leaf == true)
				return null;
		else
			return this.children[i].search(k);
	}
	
	private void split(int i)
	{
		int j = 0;
		
		if (this.isFull()) return;
		if (i > this.n) return;
		if (this.children[i] == null) return;
		if (!this.children[i].isFull()) return;
		
		BNode z = new BNode(this.minimumDegree);
		BNode y = this.children[i];
		z.leaf = y.leaf;
		z.n = this.minimumDegree - 1;
		
		for (j = 0; j < this.minimumDegree - 1; ++j)
			z.keys[j] = y.keys[j + this.minimumDegree];
		
		for (j = 0; j < this.minimumDegree; ++j)
			z.children[j] = y.children[j + this.minimumDegree];
		
		y.n = this.minimumDegree - 1;
		
		for (j = this.n; j > i; --j)
			this.children[j+1] = this.children[j];
		this.children[j+1] = z;
			
		for (j = this.n-1; j > i-1; --j)
			this.keys[j+1] = this.keys[j];
		this.keys[j+1] = y.keys[this.minimumDegree - 1];
		
		this.n = this.n + 1;
		
		for (j = this.minimumDegree; j < 2*this.minimumDegree-1; ++j)
		{
			y.keys[j] = 0;
			y.children[j] = null;
		}
		y.keys[this.minimumDegree - 1] = 0;
		y.children[j] = null;
	}
	
	public boolean insertOnNonFullNode(int k)
	{
		if(this.isFull()) return false;
		
		int i = this.n - 1;
		
		if (this.isLeaf())
		{
			while (i >= 0 && k < this.keys[i])
			{
				this.keys[i+1] = this.keys[i];
				--i;
			}
			this.keys[i+1] = k;
			this.n = this.n + 1;
			return true;
		}
		else
		{
			while (i >= 0 && k < this.keys[i])
				--i;
			
			i = i+1;
			
			if (this.children[i].isFull())
			{
				this.split(i);
				if (k > this.keys[i]) ++i;
			}
			
			return this.children[i].insertOnNonFullNode(k);
		}
	}
	
	public void print()
	{
		int i = 0;
		for (i = 0; i < this.n; ++i)
		{
			if (this.children[i] != null)
				this.children[i].print();
			System.out.print(this.keys[i] + " ");
		}
		if (this.children[i] != null)
			this.children[i].print();
	}

}

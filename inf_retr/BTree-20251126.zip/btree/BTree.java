package it.unipv.datastructures.btree;

public class BTree {
	
	private int minimumDegree = 0;
	private BNode root = null;
	
	public BTree(int minimumDegree)
	{
		this.minimumDegree = minimumDegree;
		this.root = new BNode(minimumDegree);
		this.root.setLeaf();
	}
	
	public Object[] search(int k)
	{
		return this.root.search(k);
	}
	
	public boolean insert(int k)
	{
		if (this.root.isFull())
		{
			BNode s = new BNode(this.minimumDegree);
			s.setChild(this.root, 0);
			this.root = s;
		}
		return this.root.insertOnNonFullNode(k);
	}
	
	public void print()
	{
		if (this.root == null) return;
		this.root.print();
	}

}

package it.unipv.datastructures.tree;

public class BinaryTree {
	
	private Node root = null;
	
	public void inorderTreeWalk()
	{
		if (root != null)
			root.inorderTreeWalk();
	}
	
	public Node search(int k)
	{
		if (this.root != null)
			return this.root.search(k);
		return null;
	}
	
	public void insert(Node z)
	{
		if (z == null) return;
		
		if (this.root == null) 
			this.root = z;
		else this.root.insert(z);	
	}
	
	public boolean delete (int k)
	{
		if (this.root == null) 
			return false;
		else if (this.root.getKey() == k)
		{
			this.root = this.root.delete();
			return true;
		}
		else
		{
			Node p = this.root;
			Node q = p;
			
			do
			{
				p = q;
				if (k < p.getKey())
					q = p.getLeft();
				else
					q = p.getRight();
			} while (q != null && q.getKey() != k);
			
			if (q == null) return false;
			
			if (p.getKey() > q.getKey())
				p.setLeft(q.delete());
			else
				p.setRight(q.delete());
			return true;
			
		}
	}
	
	

}

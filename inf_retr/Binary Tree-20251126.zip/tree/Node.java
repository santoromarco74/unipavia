package it.unipv.datastructures.tree;

public class Node {
	
	private int key;
	private Node left = null;
	private Node right = null;
	
	public Node(int key) {
		this.key = key;
	}
	
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	public Node getLeft() {
		return left;
	}
	public void setLeft(Node left) {
		this.left = left;
	}
	public Node getRight() {
		return right;
	}
	public void setRight(Node right) {
		this.right = right;
	}
	
	public void print()
	{
		System.out.print(key + " ");
	}
	
	public void inorderTreeWalk()
	{
		if (this.left != null)
			this.left.inorderTreeWalk();
		this.print();
		if (this.right != null)
			this.right.inorderTreeWalk();
		
	}
	
	public Node search(int k)
	{
		if (this.key == k) return this;
		else if (k < this.key && this.left != null)
			return this.left.search(k);
		else if (k > this.key && this.right != null)
			return this.right.search(k);
		return null;
	}
	
	public void insert(Node z)
	{
		if (z == null) return;
		
		if (z.getKey() < this.key && this.left != null)
			this.left.insert(z);
		else if (z.getKey() > this.key && this.right != null)
			this.right.insert(z);
		else if (z.getKey() < this.key)
			this.left = z;
		else
			this.right = z;
	}
	
	public Node delete()
	{
		// Case 1
		if (this.left == null)
			return this.right;
		// Case 2
		else if (this.right == null)
			return this.left;
		// Case 3
		else if (this.right.left == null)
		{
			this.right.left = this.left;
			return this.right;
		}
		// case 4
		else
		{
			Node p = this.right;
			Node y = this.right.left;
			
			while (y.left != null)
			{
				p = y;
				y = y.left;
			}
			
			p.left = y.right;
			y.right = this.right;
			y.left = this.left;
			return y;
		}
	}
	
}

package it.unipv.datastructures;

import it.unipv.datastructures.tree.BinaryTree;
import it.unipv.datastructures.tree.Node;

public class ManageBinaryTree {

	public static void main(String[] args) {
		
		BinaryTree bt = new BinaryTree();
		
		bt.insert(new Node(54));
		bt.insert(new Node(82));
		bt.insert(new Node(12));
		bt.insert(new Node(44));
		bt.insert(new Node(36));
		bt.insert(new Node(71));
		bt.insert(new Node(5));
		bt.insert(new Node(15));
		bt.insert(new Node(13));
		bt.insert(new Node(22));
		bt.insert(new Node(99));
		bt.insert(new Node(66));
		
		bt.inorderTreeWalk();
		
		Node n = bt.search(45);
		if (n != null) n.print();
		else System.out.print("45 wasn't found");

	}

}

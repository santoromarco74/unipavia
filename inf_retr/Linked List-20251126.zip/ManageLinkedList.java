package it.unipv.datastructures;

import it.unipv.datastructures.linkedlist.LinkedList;
import it.unipv.datastructures.linkedlist.ListElement;

public class ManageLinkedList {

	public static void main(String[] args) {
		
		LinkedList ll = new LinkedList();
		
		
		ll.insert(new ListElement(17));
		ll.insert(new ListElement(11));
		ll.insert(new ListElement(77));
		
		ll.print();
		
		ll.insert(new ListElement(20));
		ll.insert(new ListElement(9));
		ll.insert(new ListElement(80));
		
		ll.print();
		
		ListElement tmp = ll.search(77);
		if (tmp == null)
			System.out.print("Sorry but the number is not in the list");
		else
			System.out.print("The key has been found");
		
		ll.delete(77);
		
		ll.print();
		
		tmp = ll.search(77);
		if (tmp == null)
			System.out.print("Sorry but the number is not in the list");
		else
			System.out.print("The key has been found");
		
		

	}

}

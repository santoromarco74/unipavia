package it.unipv.datastructures.linkedlist;

public class ListElement {
	
	private int key;
	private ListElement next = null;
	
	public ListElement(int k)
	{
		key = k;
	}
	
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	public ListElement getNext() {
		return next;
	}
	public void setNext(ListElement next) {
		this.next = next;
	}
	
	
}

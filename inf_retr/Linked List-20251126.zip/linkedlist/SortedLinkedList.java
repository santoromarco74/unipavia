package it.unipv.datastructures.linkedlist;

public class SortedLinkedList {
	
	private ListElement head = null;
	
	public ListElement search(int k)
	{
		ListElement x = this.head;
		
		while (x != null && x.getKey() < k)
		{
			x = x.getNext();
		}
		
		if (x != null && x.getKey() == k)
			return x;
		return null;
	}
	
	public void insert(ListElement x)
	{
		if (x == null) return;
		
		ListElement tmp = this.head;
		
		if (tmp == null || tmp.getKey() >= x.getKey())
		{
			x.setNext(this.head);
			this.head = x;
		}
		else
		{
			while (tmp.getNext() != null && tmp.getNext().getKey() < x.getKey())
			{
				tmp = tmp.getNext();
			}
			
			x.setNext(tmp.getNext());
			tmp.setNext(x);
		}
	}
	
	public void print()
	{
		ListElement tmp = this.head;
		
		while (tmp != null)
		{
			System.out.print(tmp.getKey() + " ");
			tmp = tmp.getNext();
		}
		System.out.print("\n");
	}
	
	public boolean delete(int k)
	{
		if (this.head == null) return false;
		
		if (this.head.getKey() == k)
		{
			this.head = this.head.getNext();
			return true;
		}
		
		ListElement tmp = this.head;
		while (tmp.getNext() != null && tmp.getNext().getKey() <= k)
		{
			if (tmp.getNext().getKey() == k)
			{
				tmp.setNext(tmp.getNext().getNext());
				return true;
			}
			tmp = tmp.getNext();
		}
		return false;
	}
	
	

}

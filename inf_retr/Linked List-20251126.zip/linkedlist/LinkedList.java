package it.unipv.datastructures.linkedlist;

public class LinkedList {
	
	private ListElement head = null;
	
	public ListElement search(int k)
	{
		ListElement x = head;
		
		while (x != null)
		{
			if (x.getKey() == k)
				return x;
			
			x = x.getNext();
		}
		
		return null;
	}
	
	public void insert(ListElement x)
	{
		if (x == null) return;
		
		x.setNext(head);
		head = x;
	}
	
	public boolean delete(int k)
	{
		if (head == null) return false;
		
		if (head.getKey() == k)
		{
			head = head.getNext();
			return true;
		}
		
		ListElement c = head;
		
		while (c.getNext() != null)
		{
			if (c.getNext().getKey() == k)
			{
				c.setNext(c.getNext().getNext());
				return true;
			}
			c = c.getNext();
		}
		return false;
	}
	
	public void print()
	{
		ListElement tmp = this.head;
		
		while (tmp != null)
		{
			System.out.print(tmp.getKey() + " ");
			tmp = tmp.getNext();
		}
		
		System.out.print("\n");
		
	}
	
	

}

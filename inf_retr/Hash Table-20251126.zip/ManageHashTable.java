package it.unipv.datastructures;

import it.unipv.datastructures.hashtable.HashTable;
import it.unipv.datastructures.linkedlist.ListElement;

public class ManageHashTable {

	public static void main(String[] args) {
		
		HashTable ht = new HashTable();
		
		ht.insert(new ListElement(17));
		ht.insert(new ListElement(20));
		ht.insert(new ListElement(9));
		ht.insert(new ListElement(80));
		ht.insert(new ListElement(14));
		ht.insert(new ListElement(77));
		ht.insert(new ListElement(11));
		ht.insert(new ListElement(3));
		ht.insert(new ListElement(25));
		ht.insert(new ListElement(40));
		
		ht.print();
		
		ht.delete(40);
		
		ht.print();
		
	}

}

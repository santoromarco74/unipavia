package it.unipv.datastructures.hashtable;

import it.unipv.datastructures.linkedlist.LinkedList;
import it.unipv.datastructures.linkedlist.ListElement;

public class HashTable {
	
	private static final int N = 17;
	
	private LinkedList[] hashTable = new LinkedList[N];
	
	public HashTable()
	{
		for (int i = 0; i < N; ++i)
			hashTable[i] = new LinkedList();
	}
	
	private int getHash(int k)
	{
		return k % N;
	}
	
	public void insert(ListElement x)
	{
		if (x == null) return;
		
		hashTable[getHash(x.getKey())].insert(x);
	}
	
	public ListElement search(int k)
	{
		return hashTable[getHash(k)].search(k);
	}
	
	public boolean delete(int k)
	{
		return hashTable[getHash(k)].delete(k);
	}
	
	public void print()
	{
		for (int i = 0; i < N; ++i)
		{
			System.out.print("[" + i + "]:");
			hashTable[i].print();
		}
	}
	
	
	

}
